
if __name__ == '__main__':

    val = -1
    print(f'abs({val}) = {abs(val)}')

    val = 0
    print(f'abs({val}) = {abs(val)}')

    val = 1
    print(f'abs({val}) = {abs(val)}')
