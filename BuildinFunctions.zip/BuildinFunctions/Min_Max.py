

if __name__ == '__main__':
    numbers = [4, 5, 6, 7, 1, 2, 3, 8, 9]

    print(f'Max value: {max(numbers)}')
    print(f'Min value: {min(numbers)}')
    